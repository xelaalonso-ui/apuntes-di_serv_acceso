
import java.sql.*;
// ejecicios 9,7
public class ejercicios2 {
    private static Connection conexion;

    public static void abrirConexion(String bd, String servidor, String usuario, String password) {
        try {
            String url = String.format("jdbc:mariadb://%s:3306/%s", servidor, bd);
            conexion = DriverManager.getConnection(url, usuario, password);

            if (conexion != null) {
                System.out.println("Conectado a " + bd + " en " + servidor);
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
    }

    public static Connection getConexion() {
        return conexion;
    }

    public static void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }

    public static void alta(String nombre, String apellidos, int altura, int aula) {

        try (Statement st = conexion.createStatement();) {

            String consulta = "INSERT INTO alumnos(nombre,apellidos,altura,aula) VALUES('" + nombre + "','" + apellidos
                    + "'," + altura + "," + aula + ")";
            int rs = st.executeUpdate(consulta);

            System.out.println("datos subidos");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public static void asignaturas(String nombre) {

        try (Statement st = conexion.createStatement();) {

            String consulta = "INSERT INTO asignaturas(NOMBRE) VALUES('" + nombre + "')";
            int rs = st.executeUpdate(consulta);

            System.out.println("datos subidos");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public static void consulta1() {
        String consulta = "SELECT  au.nombreAula as nombre,COUNT(a.codigo) as codigo FROM aulas au JOIN alumnos a ON au.numero=a.aula  GROUP BY au.nombreAula  HAVING au.nombreAula  IS NOT null";

        try (Statement st = conexion.createStatement(); ResultSet rs = st.executeQuery(consulta)) {
            while (rs.next()) {
                System.out.println(rs.getString("nombre") + rs.getInt("codigo"));
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void notas() {
        String consulta = "select al.nombre as nombre,n.NOTA as nota,a.NOMBRE as asNombre from asignaturas a JOIN notas n on n.asignatura=a.COD join alumnos al on n.alumno=al.codigo  where n.NOTA>=5";
        try (Statement st = conexion.createStatement(); ResultSet rs = st.executeQuery(consulta)) {
            while (rs.next()) {
                System.out.println(rs.getString("nombre") + "\t" + rs.getInt("nota") + "\t" + rs.getString("asNombre"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void asignaturas() {
        String consulta = "SELECT a.NOMBRE as nombre FROM asignaturas a  LEFT JOIN notas n ON a.COD = n.asignatura WHERE n.asignatura IS NULL;";
        try (Statement st = conexion.createStatement(); ResultSet rs = st.executeQuery(consulta)) {
            while (rs.next()) {
                System.out.println(rs.getString("nombre"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    // con consulta sin secuencia preparada
    public static void alunosConPara(String parametro, int altura) {
        String consulta = "select nombre ,altura from alumnos where nombre like '%" + parametro + "%' and altura>"
                + altura + "";
        try (Statement st = conexion.createStatement(); ResultSet rs = st.executeQuery(consulta)) {
            while (rs.next()) {
                System.out.println(rs.getString("nombre") + "\t" + rs.getInt("altura"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    // con consulta preparada//
    public static void alunosConParaSeguro(String parametro, int altura) {
        String consulta = "select nombre, altura from alumnos "
                + "where nombre like ? and altura > ?";
        try (PreparedStatement ps = conexion.prepareStatement(consulta);) {
            ps.setString(1, "%" + parametro + "%");
            ps.setInt(2, altura);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getString("nombre") + "\t" + rs.getInt("altura"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public static void ej8(String tabla, String nombre, String tipoDato, String propiedades) {
        

        try(Statement st=conexion.createStatement()) {
            String cosulta="ALTER TABLE " + tabla + " ADD COLUMN " + nombre + " " + tipoDato + " " + propiedades;
        
            int rs=st.executeUpdate(cosulta);
            System.out.println("tabla creada");
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    //ejercicio 9
   

    public static void main(String[] args) {
        abrirConexion("add", "localhost", "root", "");
    //    // int[] tiempo = { 1, 10, 100, 1000, 10000, 100000, 1000000 };

        // for (int n : tiempo) {
        //     long inicio = System.nanoTime();
        //     for (int i = 0; i > n; i++) {
        //         alta("paco", "paco2", 12, 5);
        //         asignaturas("programacion");
        //         notas();
        //         consulta1();
        //         asignaturas();
        //         alunosConPara("C", 170);
        //         alunosConParaSeguro("C", 170);
        //     }
        //     long fin = System.nanoTime();
        //     double tiempos = (fin - inicio) / 1_000_000_000.0;
        //     System.out.println("Iteraciones: " + n + " → Tiempo: " + tiempos + " s");
        // }

        // alta("paco", "paco2", 12, 5);
        // asignaturas("programacion");
        // notas();
        // consulta1();
        // asignaturas();
        // alunosConPara("C", 170);
        // alunosConParaSeguro("C", 170);
        ej8("alumnos", "perro", "int", null);
        cerrarConexion();
    }

}
