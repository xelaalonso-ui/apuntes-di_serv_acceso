
import java.sql.*;

public class Ejercicios {

    private static Connection conexion;

    public static void abrirConexion(String bd, String servidor, String usuario,
            String password) {
        try {
            String url = String.format("jdbc:mariadb://%s:3306/%s", servidor, bd);
            //Establecemos la conexión con la BD
            conexion = DriverManager.getConnection(url, usuario, password);
            if (conexion != null) {
                System.out.println("Conectado a " + bd + " en " + servidor);
            } else {
                System.out.println("No conectado a " + bd + " en " + servidor);
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getLocalizedMessage());
            System.out.println("SQLState: " + e.getSQLState());
            System.out.println("Código error: " + e.getErrorCode());
        }

    }

    public static void cerrarConexion() {
        try {
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión: " + e.getLocalizedMessage());
        }
    }

    public static void consultarJugadores() {
        try (Statement st = conexion.createStatement()) {
            String consulta = "select*from jugadores_celta";
            ResultSet rs = st.executeQuery(consulta);
            while (rs.next()) {
                System.out.println(rs.getInt(1) + "//" + rs.getString(2));

            }
        } catch (SQLException e) {
        }

    }

    public static void consultaredad() {
        try (Statement st = conexion.createStatement()) {
            String consulta = "select * from jugadores_celta where edad>30";
            ResultSet rs = st.executeQuery(consulta);
            while (rs.next()) {
                System.out.println(rs.getInt(4) + "//" + rs.getString(2));
            }
        } catch (SQLException e) {
        }

    }
    public static  void getinfo(String bd){
        try {
            DatabaseMetaData dbmd=conexion.getMetaData();
            ResultSet tablas=dbmd.getTables(bd,null, null,null);
            while(tablas.next()){
                System.out.println(tablas.getString("TABLE-NAME")+""+tablas.getString("TABEL_TYP"));
               // ResultSet colunas=dbmd.getColumns(db, null,tablas.getString(columnIndex), bd)
            }       
        } catch (SQLException e) {
        }
    }

    public static void consultaInsertar(int id) {
        try (Statement st = conexion.createStatement()) {
            String insertar = "INSERT INTO jugadores_celta(DORSAL,NOMBRE,POSICION,EDAD,NACIONALIDAD,CONVOCAD,PARTIDOS_JUGADOS,GOLES,MINUTOS_JUGADOS) value ('69','Manuel','delantero','25','españa','12','6','6','580')";
            int rs = st.executeUpdate(insertar);
            System.out.println(rs);
        } catch (SQLException e) {
            System.out.println("error");
        }

    }
    private  static  PreparedStatement ps=null;
    public  static  void  consultar(int dorsal,int edad) throws SQLException{
        String consult="Select *from jugadores_celta where dorsal=? and edad =?";
        ps =conexion.prepareStatement(consult);
        ps.setInt(1, dorsal);
        ps.setInt(2, edad);
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
                
        }
    }

    public static void main(String[] args) {
        abrirConexion("celta", "localhost", "root", "");
        //consultarJugadores();
        //consultaredad();
        //consultaInsertar();
        cerrarConexion();
    }
}
