
import java.sql.*;

public class Ejercicio1 {

    private static Connection conexion;

    // ================= CONEXIÓN =================
    public static void abrirConexion(String bd, String servidor, String usuario, String password) {
        try {
            String url = String.format("jdbc:mariadb://%s:3306/%s", servidor, bd);
            conexion = DriverManager.getConnection(url, usuario, password);

            if (conexion != null) {
                System.out.println("Conectado a " + bd + " en " + servidor);
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
    }

    public static Connection getConexion() {
        return conexion;
    }

    public static void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }

    // ================= 1. Buscar alumnos =================
    public static void cadena() {
        String consulta = "SELECT codigo, nombre, apellidos, altura, aula FROM alumnos WHERE nombre LIKE '%Julio%'";

        try (Statement st = conexion.createStatement(); ResultSet rs = st.executeQuery(consulta)) {

            while (rs.next()) {
                System.out.println(
                        rs.getInt("codigo") + " // "
                        + rs.getString("nombre") + " // "
                        + rs.getString("apellidos") + " // "
                        + rs.getInt("altura") + " // "
                        + rs.getInt("aula")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error en cadena(): " + e.getMessage());
        }
    }

    // ================= 2. Alta =================
    public static void alta(String nombre, String apellido, int altura, int aula) {
        String sql = "INSERT INTO alumnos (nombre, apellidos, altura, aula) VALUES (?, ?, ?, ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setString(2, apellido);
            ps.setInt(3, altura);
            ps.setInt(4, aula);

            int filas = ps.executeUpdate();
            System.out.println("Alumno dado de alta. Filas: " + filas);

        } catch (SQLException e) {
            System.out.println("Error en alta(): " + e.getMessage());
        }
    }

    // ================= 3. Baja =================
    public static void baja(int codigo) {
        String sql = "DELETE FROM alumnos WHERE codigo = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, codigo);
            int filas = ps.executeUpdate();

            if (filas > 0) {
                System.out.println("Alumno eliminado."); 
            }else {
                System.out.println("No existe ese alumno.");
            }

        } catch (SQLException e) {
            System.out.println("Error en baja(): " + e.getMessage());
        }
    }

    // ================= 4. Modificar =================
    public static void modificar(int codigo, String nombre, String apellidos, int altura, int aula) {
        String sql = "UPDATE alumnos SET nombre=?, apellidos=?, altura=?, aula=? WHERE codigo=?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setString(2, apellidos);
            ps.setInt(3, altura);
            ps.setInt(4, aula);
            ps.setInt(5, codigo);

            int filas = ps.executeUpdate();

            if (filas > 0) {
                System.out.println("Alumno modificado."); 
            }else {
                System.out.println("No existe ese alumno.");
            }

        } catch (SQLException e) {
            System.out.println("Error en modificar(): " + e.getMessage());
        }
    }

    // ================= 5. Aulas =================
    public static void aulasConAlumnos() {
        String sql = "SELECT numero, nombreAula FROM aulas WHERE numero > 0";

        try (PreparedStatement ps = conexion.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                System.out.println(rs.getInt("numero") + " - " + rs.getString("nombreAula"));
            }

        } catch (SQLException e) {
            System.out.println("Error en aulasConAlumnos(): " + e.getMessage());
        }
    }

    // ================= 6. Nombre y altura =================
    public static void buscarPorNombreAltura(String patron, int altura) {
        String sql = "SELECT * FROM alumnos WHERE nombre LIKE ? AND altura > ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, "%" + patron + "%");
            ps.setInt(2, altura);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getString("nombre"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= usado en medirTiempo =================
    public static void buscarAlumnosPorNombre(String patron) {
        String sql = "SELECT nombre FROM alumnos WHERE nombre LIKE ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, "%" + patron + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                rs.getString("nombre");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= 7. Medir tiempo =================
    public static void medirTiempo(int veces) {
        long inicio = System.nanoTime();

        for (int i = 0; i < veces; i++) {
            buscarAlumnosPorNombre("Ju");
        }

        long fin = System.nanoTime();
        System.out.println("Veces: " + veces + " -> Tiempo: " + (fin - inicio));
    }

    //==============8.Columas devueltas ======================
    public static void columnasDevueltas() {

    }
// ================= 9. DatabaseMetaData =================

    public static void infoBD() throws SQLException {
        try (Connection con = getConexion()) {
            DatabaseMetaData meta = con.getMetaData();

            System.out.println("Driver: " + meta.getDriverName());
            System.out.println("Versión driver: " + meta.getDriverVersion());
            System.out.println("URL: " + meta.getURL());
            System.out.println("Usuario: " + meta.getUserName());
            System.out.println("SGBD: " + meta.getDatabaseProductName());
            System.out.println("Versión SGBD: " + meta.getDatabaseProductVersion());
            System.out.println("Palabras reservadas: " + meta.getSQLKeywords());

            ResultSet catalogs = meta.getCatalogs();
            while (catalogs.next()) {
                System.out.println("BD: " + catalogs.getString(1));
            }
        }
    }

    // ================= 10. Columnas devueltas ======================
    public static void columnasDevuelta() {
        String sql = "SELECT *, nombre AS non FROM alumnos";

        try (Statement st = conexion.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            ResultSetMetaData rsMeta = rs.getMetaData();
            int columnas = rsMeta.getColumnCount();

            for (int i = 1; i <= columnas; i++) {
                System.out.println("Columna " + i + ":");
                System.out.println("  Nombre: " + rsMeta.getColumnName(i));
                System.out.println("  Alias: " + rsMeta.getColumnLabel(i));
                System.out.println("  Tipo de dato: " + rsMeta.getColumnTypeName(i));
                System.out.println("  Autoincremental: " + rsMeta.isAutoIncrement(i));
                System.out.println("  Permite nulos: " + (rsMeta.isNullable(i) == ResultSetMetaData.columnNullable));
                System.out.println("-----------------------------------");
            }

        } catch (SQLException e) {
            System.out.println("Error en columnasDevueltas(): " + e.getMessage());
        }
    }

    // ================= 12. Insertar alumnos con transacción ======================
    public static void insertarAlumnosConTransaccion() {
        String sql = "INSERT INTO alumnos (id, nombre, apellidos, altura, aula) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            conexion.setAutoCommit(false); // desactivar autocommit

            // Inserción correcta
            ps.setInt(1, 201);
            ps.setString(2, "Ana");
            ps.setString(3, "García");
            ps.setInt(4, 170);
            ps.setInt(5, 1);
            ps.executeUpdate();

            // Inserción correcta
            ps.setInt(1, 202);
            ps.setString(2, "Luis");
            ps.setString(3, "Pérez");
            ps.setInt(4, 175);
            ps.setInt(5, 2);
            ps.executeUpdate();

            // Inserción que genera error (duplicado)
            ps.setInt(1, 202); // id duplicado
            ps.setString(2, "Marta");
            ps.setString(3, "López");
            ps.setInt(4, 165);
            ps.setInt(5, 1);
            ps.executeUpdate();

            // Si todo bien, confirmar transacción
            conexion.commit();
            System.out.println("Todos los alumnos insertados correctamente.");

        } catch (SQLException e) {
            try {
                if (conexion != null) {
                    conexion.rollback(); // deshacer todos los cambios
                    System.out.println("Error en la inserción. Todos los cambios se han deshecho.");
                    System.out.println("Código de error: " + e.getErrorCode());
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } finally {
            try {
                conexion.setAutoCommit(true); // volver a modo normal
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // ================= 13a. Leer imagen desde BD y guardar en disco ======================
    public static void leerImagen(int idImagen, String rutaSalida) {
        String sql = "SELECT imagen FROM imagenes WHERE id = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idImagen);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                InputStream is = rs.getBinaryStream("imagen");
                FileOutputStream fos = new FileOutputStream(rutaSalida);

                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                }

                fos.close();
                is.close();
                System.out.println("Imagen guardada en: " + rutaSalida);
            }

        } catch (SQLException | IOException e) {
            System.out.println("Error en leerImagen(): " + e.getMessage());
        }
    }

    // ================= 13b. Guardar imagen desde disco en BD ======================
    public static void guardarImagen(int idImagen, String rutaArchivo) {
        String sql = "INSERT INTO imagenes (id, imagen) VALUES (?, ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql);
             FileInputStream fis = new FileInputStream(rutaArchivo)) {

            ps.setInt(1, idImagen);
            ps.setBinaryStream(2, fis, (int) new File(rutaArchivo).length());
            ps.executeUpdate();

            System.out.println("Imagen guardada en la base de datos con ID: " + idImagen);

        } catch (SQLException | IOException e) {
            System.out.println("Error en guardarImagen(): " + e.getMessage());
        }
    }

    // ================= 15. Ejecutar procedimiento y función ======================
    public static void ejecutarProcedimientoYFuncion() {
        try {
            // Llamar procedimiento almacenado getAulas
            CallableStatement cs = conexion.prepareCall("{CALL getAulas()}");
            ResultSet rs = cs.executeQuery();
            System.out.println("Resultado del procedimiento getAulas:");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + " - " + rs.getString(2));
            }
            rs.close();
            cs.close();

            // Llamar función Suma (asumiendo que recibe dos enteros)
            CallableStatement cf = conexion.prepareCall("{? = CALL Suma(?, ?)}");
            cf.registerOutParameter(1, Types.INTEGER);
            cf.setInt(2, 5);
            cf.setInt(3, 10);
            cf.execute();
            int resultado = cf.getInt(1);
            System.out.println("Resultado de la función Suma: " + resultado);
            cf.close();

        } catch (SQLException e) {
            System.out.println("Error en ejecutarProcedimientoYFuncion(): " + e.getMessage());
        }
    }

    // ================= 16. Buscar cadena en cualquier tabla/columna ======================
    public static void buscarCadena(String cadenaBuscada, String bd) {
        try {
            DatabaseMetaData meta = conexion.getMetaData();
            ResultSet tablas = meta.getTables(bd, null, "%", new String[]{"TABLE"});

            while (tablas.next()) {
                String tabla = tablas.getString("TABLE_NAME");
                ResultSet columnas = meta.getColumns(bd, null, tabla, "%");

                while (columnas.next()) {
                    String columna = columnas.getString("COLUMN_NAME");
                    String tipo = columnas.getString("TYPE_NAME");

                    if (tipo.equalsIgnoreCase("CHAR") || tipo.equalsIgnoreCase("VARCHAR")) {
                        String sql = "SELECT `" + columna + "` FROM `" + tabla + "` WHERE `" + columna + "` LIKE ?";
                        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
                            ps.setString(1, "%" + cadenaBuscada + "%");
                            ResultSet rs = ps.executeQuery();
                            while (rs.next()) {
                                String valor = rs.getString(1);
                                System.out.println("BD: " + bd + " | Tabla: " + tabla + " | Columna: " + columna + " | Valor: " + valor);
                            }
                        }
                    }
                }
            }

        } catch (SQLException e) {
            System.out.println("Error en buscarCadena(): " + e.getMessage());
        }
    }

   



    // ================= MAIN =================
    public static void main(String[] args) {
        abrirConexion("add", "localhost", "root", "");

        cadena();
        // alta("Paco", "Gómez", 170, 2);
        // baja(10);
        // modificar(11, "Ana", "López", 165, 3);
        // aulasConAlumnos();
        // buscarPorNombreAltura("Ju", 160);
           abrirConexion("add", "localhost", "root", "");

        // Ejercicio 10
        columnasDevueltas();

        // Ejercicio 12
        insertarAlumnosConTransaccion();

        // Ejercicio 13
        guardarImagen(1, "C:\\imagenes\\foto1.jpg");
        leerImagen(1, "C:\\imagenes\\salida.jpg");

        // Ejercicio 15
        ejecutarProcedimientoYFuncion();

        // Ejercicio 16
        buscarCadena("Ju", "add");

        

        cerrarConexion();
    }

}