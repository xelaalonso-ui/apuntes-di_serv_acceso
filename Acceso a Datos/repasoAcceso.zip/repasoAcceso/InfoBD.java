import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InfoBD {
    private static Connection conexion;

    public static void abrirConexion(String bd, String servidor, String usuario, String password) {
        try {
            String url = String.format("jdbc:mariadb://%s:3306/%s", servidor, bd);
            conexion = DriverManager.getConnection(url, usuario, password);

            if (conexion != null) {
                System.out.println("Conectado a " + bd + " en " + servidor);
            }
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
    }

    public static Connection getConexion() {
        return conexion;
    }

    public static void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }
   // ej 9: Obtención de columnas de tablas que comienzan por 'a'
public static void getColumnasATabla(String bd) {
    DatabaseMetaData dbmt;
    ResultSet rs;
    boolean hayAutoIncrement = false; // Para marcar si encontramos alguna columna autoincrement

    try {
        // Obtenemos los metadatos de la conexión
        dbmt = conexion.getMetaData();

        // ===== a. Información del driver y SGBD =====
        System.out.println("=== INFORMACIÓN DEL DRIVER Y SGBD ===");
        System.out.println("Driver: " + dbmt.getDriverName());
        System.out.println("Versión Driver: " + dbmt.getDriverVersion());
        System.out.println("URL: " + dbmt.getURL());
        System.out.println("Usuario: " + dbmt.getUserName());
        System.out.println("SGBD: " + dbmt.getDatabaseProductName());
        System.out.println("Versión SGBD: " + dbmt.getDatabaseProductVersion());
        System.out.println("Palabras reservadas: " + dbmt.getSQLKeywords());

        // ===== b. Todas las bases de datos (Catalogs) =====
        System.out.println("\n=== CATALOGOS DEL SGBD ===");
        rs = dbmt.getCatalogs();
        while (rs.next()) {
            System.out.println("Base de datos: " + rs.getString("TABLE_CAT"));
        }

        // ===== c. Todas las tablas de la base de datos ADD =====
        System.out.println("\n=== TABLAS DE ADD ===");
        rs = dbmt.getTables(bd, null, null, new String[]{"TABLE"});
        while (rs.next()) {
            System.out.println("Tabla: " + rs.getString("TABLE_NAME") +
                    " | Tipo: " + rs.getString("TABLE_TYPE"));
        }

        // ===== d. Solo vistas de la base de datos ADD =====
        System.out.println("\n=== VISTAS DE ADD ===");
        rs = dbmt.getTables(bd, null, null, new String[]{"VIEW"});
        while (rs.next()) {
            System.out.println("Vista: " + rs.getString("TABLE_NAME"));
        }

        // ===== e. Combinar catalogs y tablas =====
        System.out.println("\n=== CATALOGOS Y TABLAS COMBINADOS ===");
        ResultSet catalogs = dbmt.getCatalogs();
        while (catalogs.next()) {
            String catalog = catalogs.getString("TABLE_CAT");
            System.out.println("Catalog: " + catalog);
            ResultSet tablasCatalog = dbmt.getTables(catalog, null, null, new String[]{"TABLE"});
            while (tablasCatalog.next()) {
                System.out.println("   Tabla: " + tablasCatalog.getString("TABLE_NAME"));
            }
        }

        // ===== f. Procedimientos almacenados de ADD =====
        System.out.println("\n=== PROCEDIMIENTOS ALMACENADOS ===");
        rs = dbmt.getProcedures(bd, null, null);
        while (rs.next()) {
            System.out.println("Procedimiento: " + rs.getString("PROCEDURE_NAME"));
        }

        // ===== g. Columnas de tablas que comienzan por 'a' =====
        System.out.println("\n=== COLUMNAS DE TABLAS QUE COMIENZAN POR 'a' ===");
        rs = dbmt.getTables(bd, null, "a%", new String[]{"TABLE"});
        while (rs.next()) {
            String nombreTabla = rs.getString("TABLE_NAME");
            System.out.println("Tabla: " + nombreTabla);

            ResultSet columnas = dbmt.getColumns(bd, null, nombreTabla, null);
            while (columnas.next()) {
                String nombreColumna = columnas.getString("COLUMN_NAME");
                String tipo = columnas.getString("TYPE_NAME");
                int tamaño = columnas.getInt("COLUMN_SIZE");
                String nulo = columnas.getString("IS_NULLABLE");
                String autoInc = columnas.getString("IS_AUTOINCREMENT");

                // Mostramos la información de cada columna
                System.out.println(String.format(
                        " Posición: %d | BD: %s | Tabla: %s | Columna: %s | Tipo: %s | Tamaño: %d | Nulo: %s | AutoInc: %s",
                        columnas.getInt("ORDINAL_POSITION"),
                        columnas.getString("TABLE_CAT"),
                        nombreTabla,
                        nombreColumna,
                        tipo,
                        tamaño,
                        nulo,
                        autoInc
                ));

                if ("YES".equalsIgnoreCase(autoInc)) {
                    hayAutoIncrement = true;
                }
            }
        }

        // Indicar si se encontró alguna columna autoincrement
        if (hayAutoIncrement) {
            System.out.println("Se encontró al menos una columna autoincrement.");
        } else {
            System.out.println("No se encontraron columnas autoincrement.");
        }


    } catch (SQLException e) {
        System.out.println("Error obteniendo columnas " + e.getLocalizedMessage());
    }
} 
public static void main(String[] args) {
    abrirConexion("add", "localhost", "root", "");
    getColumnasATabla("add");
    cerrarConexion();
}
}
